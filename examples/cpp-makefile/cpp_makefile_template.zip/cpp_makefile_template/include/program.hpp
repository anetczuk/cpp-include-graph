#ifndef INCLUDE_PROGRAM_HPP
#define INCLUDE_PROGRAM_HPP

#include <cstdio>

namespace program
{
    inline void foo()
    {
        printf("program::foo()\n");
    }
}

#endif
