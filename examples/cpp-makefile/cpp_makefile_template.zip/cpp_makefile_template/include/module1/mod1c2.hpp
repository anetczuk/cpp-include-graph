#ifndef INCLUDE_MOD1C2_HPP
#define INCLUDE_MOD1C2_HPP

#include <iostream>

class mod1c2
{
public:

   void foo();

};

#endif
